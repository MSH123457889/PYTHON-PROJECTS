def draw_encg_fes():
    E = ["*****", "*    ", "**** ", "*    ", "*****"]
    N = ["*   *", "**  *", "* * *", "*  **", "*   *"]
    C = [" ****", "*    ", "*    ", "*    ", " ****"]
    G = [" ****", "*    ", "*  **", "*   *", " ****"]

    F = ["*****", "*    ", "**** ", "*    ", "*    "]
    S = [" ****", "*    ", " *** ", "    *", "**** "]

    space = ["     "] * 5  # space between letters

    # Combine letters to form the phrase
    letters = [E, N, C, G, space, F, E, S]

    for i in range(5):  # each line
        line = ""
        for letter in letters:
            line += letter[i] + "  "
        print(line)

draw_encg_fes()
